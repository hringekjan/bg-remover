// batch-embeddings implementation placeholder
export const batchEmbeddings = () => {};
