"""Exposes version constant to avoid circular dependencies."""

VERSION = "2.40.0"
